create view vueproduitcategorie (id, nom_prod, marque, taille, prix, stock, catégorie_id, nom_categorie) as
SELECT p.id,
       p.nom_prod,
       p.marque,
       p.taille,
       p.prix,
       p.stock,
       p."catégorie_id",
       c.nom_cat AS nom_categorie
FROM produit p
         JOIN "catégorie" c ON p."catégorie_id" = c.id_cat;

alter table vueproduitcategorie
    owner to anonyme;

