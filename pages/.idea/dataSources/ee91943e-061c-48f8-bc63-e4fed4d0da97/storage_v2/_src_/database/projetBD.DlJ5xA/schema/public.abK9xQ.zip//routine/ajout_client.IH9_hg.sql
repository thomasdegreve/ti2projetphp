create function ajout_client(text, text, text, text, text, text) returns integer
    language plpgsql
as
$$
  declare p_nom alias for $1;
  declare p_prenom alias for $2;
  declare p_email alias for $3;
  declare p_adresse alias for $4;
  declare p_tel alias for $5;
  declare p_pwd alias for $6;
  declare id integer;
  declare retour integer;
  
begin
	select into id id from client where emailcl = p_email;
	if not found
	then
	  insert into client (nom,prénom,emailcl,adresse,téléphone,password) values
	    (p_nom,p_prenom,p_email,p_adresse,p_tel,p_pwd);
	  select into id id from client where emailcl = p_email;
	  if not found
	  then	
	    retour = -1;  --échec de la requête
	  else
	    retour = 1;   -- insertion ok
	  end if;
	else
	  retour = 0;      -- déjà en BD
	end if;
 return retour;
 end;
$$;

alter function ajout_client(text, text, text, text, text, text) owner to anonyme;

