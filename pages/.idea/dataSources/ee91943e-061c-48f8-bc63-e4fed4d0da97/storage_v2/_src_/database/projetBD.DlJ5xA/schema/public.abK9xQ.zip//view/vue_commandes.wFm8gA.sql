create view vue_commandes(date, statut, id_client, id_produit) as
SELECT c.date,
       c.statut,
       cl.id AS id_client,
       p.id  AS id_produit
FROM commande c
         JOIN client cl ON c.client_id = cl.id
         JOIN produit p ON c.produit_id = p.id;

alter table vue_commandes
    owner to anonyme;

