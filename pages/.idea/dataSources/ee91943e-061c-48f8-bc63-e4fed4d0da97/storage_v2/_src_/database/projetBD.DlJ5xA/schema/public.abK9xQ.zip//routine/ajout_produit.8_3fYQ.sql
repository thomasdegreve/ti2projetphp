create function ajout_produit(p_nom_prod character varying, p_marque character varying, p_taille character varying, p_prix numeric, p_stock integer, p_categorie_id integer, p_image character varying) returns integer
    language plpgsql
as
$$
DECLARE
    id_produit INTEGER;
    retour INTEGER;
BEGIN
    -- Vérifier si le produit existe déjà dans la base de données
    SELECT id INTO id_produit FROM produits WHERE nom_prod = p_nom_prod LIMIT 1;

    IF NOT FOUND THEN
        -- Si le produit n'existe pas, l'ajouter
        INSERT INTO produits (nom_prod, marque, taille, prix, stock, categorie_id, image)
        VALUES (p_nom_prod, p_marque, p_taille, p_prix, p_stock, p_categorie_id, p_image)
        RETURNING id INTO id_produit;

        -- Vérifier si l'ajout a réussi
        IF id_produit IS NULL THEN
            retour = -1;  -- Échec de l'insertion
        ELSE
            retour = 1;   -- Insertion réussie
        END IF;
    ELSE
        retour = 0;      -- Produit déjà en base de données
    END IF;

    RETURN retour;
END;
$$;

alter function ajout_produit(varchar, varchar, varchar, numeric, integer, integer, varchar) owner to anonyme;

