create function verifier_admin(text, text) returns integer
    language plpgsql
as
$$
	declare p_login alias for $1;
	declare p_password alias for $2;
	declare id integer;
	declare retour integer;
	
begin
	select into id id_admin from admin where login=p_login and password = p_password;
	if not found 
	then
	  retour = 0;
	else
	  retour =1;
	end if;  
	return retour;
end;
$$;

alter function verifier_admin(text, text) owner to anonyme;

