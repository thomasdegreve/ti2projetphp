create view vue_commande(date, statut, nom_client, nom_produit) as
SELECT c.date,
       c.statut,
       cl.nom     AS nom_client,
       p.nom_prod AS nom_produit
FROM commande c
         JOIN client cl ON c.client_id = cl.id
         JOIN produit p ON c.produit_id = p.id;

alter table vue_commande
    owner to anonyme;

